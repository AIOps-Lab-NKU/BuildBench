"""Build-Bench Example Agent."""
